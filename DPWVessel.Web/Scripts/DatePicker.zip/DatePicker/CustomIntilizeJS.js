﻿$('#sandbox-container .input-group.date').datepicker({
    format: "dd/mm/yyyy",
    autoclose: true,
    todayBtn: "linked",
    todayHighlight: true,
    forceParse: true,
});
